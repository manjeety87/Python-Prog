x = input("Please enter your Sheridan's student number")

# def printFun(n):
    # while n >= n:
        # print(n)
        # break
    
# for n in x:
#     n = int(n)
#     for i in range(n):
#           print(n,end=" ")
#     print("")

for n in x:
    n = int(n)
    i = 0
    while i < n:
        print(n, end=" ")
        i += 1
    print("")

# def printFun(n):
#     for i in range(n):
#           print(n,end=" ")
#     print("")
    
# for n in x:
#     n = int(n)
#     printFun(n)