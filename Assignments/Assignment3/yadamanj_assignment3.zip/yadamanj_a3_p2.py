from datetime import datetime

# I have took conversion rate of 14th Nov 2024

# Japanese yen	        0.009050	0.009110	Bank holiday	0.009020	0.009010
# Chinese renminbi	     0.1941	      0.1938	Bank holiday	0.1928	      0.1936
# Indian rupee	         0.01645	 0.01649    Bank holiday    0.01652	     0.01656
# New Zealand dollar	 0.8349	      0.8304	Bank holiday	0.8267	      0.8243
# Saudi riyal	         0.3691	      0.3704	Bank holiday	0.3711	      0.3721
# Swiss franc	         1.5883	      1.5901	Bank holiday	1.5807	      1.5809
# Taiwanese dollar	    0.04315	      0.04319	Bank holiday	0.04296	     0.04307


# currencies = {
#     "Renminbi" : ("CNY", 0.009010), 
#     "Yen" : ("JPY", 0.1936),
#     "Rupee" : ("INR", 0.01656),
#     "Dollar" : ("USD", 0.8243),
#     "Riyal" : ("SAR", 0.3721),
#     "Franc" : ("CHF", 1.5809),
#     "Wan" : ("TWD", 0.04307)
#     }
currencies = {
    "CNY" : ("Renminbi", 0.009010), 
    "JPY" : ("Yen", 0.1936),
    "INR" : ("Rupee", 0.01656),
    "USD" : ("Dollar", 0.8243),
    "SAR" : ("Riyal", 0.3721),
    "CHF" : ("Franc", 1.5809),
    "TWD" : ("Wan", 0.04307)
    }
print(currencies)


def convertToCad(currencyCode, amount):
    if currencyCode in currencies:
        result = amount * currencies[currencyCode][1]
        # print(result)
        print(f"{result} CAD")
    else:
        print("\nError : Invalid currency code. \n")
    # return result

convertToCad("CHF", 20)
def convertFromCad(currency_code, amount):
    if currency_code in currencies:
        result = amount / currencies[currency_code][1]
        print(f"{result} {currency_code}")
    else:
        print("\nError : Invalid currency code. \n")

# convertFromCad("INR", 100)

menu = ["List all currencies in the dictionary", 
        "Convert an amount to CAD",
        "Convert an amount from CAD",
        "Quit"
        ]

def dateConversion():
    lastConversionUpdated = "2024-11-14"
    currentDate = datetime.now().strftime('%Y-%m-%d')
    dateFormat = "%Y-%m-%d"
    d1 = datetime.strptime(lastConversionUpdated, dateFormat)
    print("D1",d1)
    d2 = datetime.strptime(currentDate, dateFormat)
    print("D2",d2)
    delta = d2 - d1
    days_old = delta.days
    print(f"Currency conversion is using rates from {lastConversionUpdated} and it is {days_old} days old.")

dateConversion()

while True:
    print("Please choose an option:")
    for i in range(len(menu)):
        print(i+1,menu[i])

    option = input("Enter your choice: ")
    if not option.isnumeric():
        print("\n Invalid input. Please try again using numbers. \n")
        continue
    option = int(option)

    if option == 1:
        print("\n These are the available currencies :",currencies)
    elif option == 2:
        currencyCode = input("Enter currency code: ")
        amount = float(input("Enter amount: "))
        convertToCad(currencyCode, amount)
    elif option == 3:
        currencyCode = input("Enter currency code: ")
        amount = float(input("Enter amount: "))
        convertFromCad(currencyCode, amount)
    elif option == 4:
        print("Thanks for using the currency converter. Goodbye! Have a nice day.")
        break