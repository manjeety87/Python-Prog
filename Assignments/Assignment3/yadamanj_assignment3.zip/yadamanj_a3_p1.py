fruits = {  "apple" : 1,  "banana" : 2,  "cherry" : 3,  "date" : 5,  "elderberry" : 6 }
print(fruits)  # a

fruits["fig"] = 7 
fruits["grape"] = 8 
print(fruits)

fruits["banana"] = 87
print(fruits)

del fruits["date"]
print(fruits)

for key, value in fruits.items():
    fruits[key] *= 2
print(fruits)


temp = fruits["apple"]
fruits["apple"] = fruits["banana"]
fruits["banana"] = temp
# fruits["banana"],fruits["apple"] = fruits["apple"],fruits["banana"]
print(fruits)


print("Total number of items after modifications : ", len(fruits))