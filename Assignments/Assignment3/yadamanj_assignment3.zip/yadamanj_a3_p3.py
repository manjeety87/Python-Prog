def checkRating(rating):
    if 0 <= rating <= 10:
        return True
    else:
        print("Error: Please give ratings between 0 to 10.")
    return False

class Movie:
    def __init__(self, title, director, release_year, rating):
        self.__title = title
        self.__director = director
        self.__release_year = release_year
        self.__rating = rating

    def get_title(self):
        return self.__title

    def get_director(self):
        return self.__director

    def set_title(self, title):
        self.__title = title

    def set_director(self, director):
        self.__director = director

    def get_rating(self):
        return self.__rating

    def set_rating(self, rating):
        if checkRating(rating):
            self.__rating = rating
        # self.__rating = rating




# print(movie2.get_title())
# print(movie2.set_title("The Avengers"))
# print(movie2.get_title())
# print(movie2.get_director())
# print(movie2.set_director("Stanley"))
# print(movie2.get_director())
# print(movie2.get_rating())
# print(movie2.set_rating(8.0))
# print(movie2.get_release_year())
# print(movie2.set_release_year(1999))

class MovieCollection():
# class MovieCollection(Movie):
    # def __init__(self,title, director, release_year, rating):
        # super().__init__(title, director, release_year, rating)
    def __init__(self):
        self.movies = {}

    def add_movie(self, movie):
        # print("MOVIE : ",movie)
        # print("MOVIE : ",movie.get_title())
        if movie.get_title() in self.movies:
            print(f"'{movie.get_title()}' already exists in the movie collection.")
        else:
            self.movies[movie.get_title()] = movie
        # print(self.movies)

    def get_movie(self, title):
        # print("GET MOVIE ::::: ",self.movies[title])
        if title in self.movies:
            # for movie in self.movies.values():
            # print("LIST MOVIES ::::: ",movie.get_title())
            print(f"Title: {self.movies[title].get_title()}, Director: {self.movies[title].get_director()}, Rating: {self.movies[title].get_rating()}")
            return self.movies[title]  # here it was stated that returns the movie object associated with the title so returning the whole object but it is in giving the object location so its not in reading form so adding the print statement to read the data correctly
        else:
            print(f"'{title}' does not exist in the movie collection.")

    def remove_movie(self, title):
        if title in self.movies:
            del self.movies[title]
        else:
            print(f"Error : '{title}' does not exist in the movie collection.")
    def list_movies(self):  # reference from w3schools
        for movie in self.movies.values():
            # print("LIST MOVIES ::::: ",movie.get_title())
            print(f"Title: {movie.get_title()}, Director: {movie.get_director()}, Rating: {movie.get_rating()}")


def main():
    movie1 = Movie("The Matrix", "Lana Wachowski", 1999, 8.7)
    movie2 = Movie("Avengers", "Joss Whedon", 2012, 8.0)
    movie3 = Movie("Deadpool & Wolverine", "Manjeet", 2024, 9.0)
    movie4 = Movie("Captain America", "Russo Brothers", 2020, 9.7)

    myMovieCollection = MovieCollection()
    # print("Movie 1 : ",movie1)
    myMovieCollection.add_movie(movie1)
    myMovieCollection.add_movie(movie2)
    myMovieCollection.add_movie(movie3)
    myMovieCollection.add_movie(movie4)
    print(myMovieCollection.list_movies())  # while listing the movie I'm not showing the release year as it's function is also not defined in the movie class. But while printing the movies using __str__ it was giving error so I'm not showing it. I will try something to show it later on. 
    # print(myMovieCollection.list_movies())
    myMovieCollection.remove_movie("The Matrix")
    # print(myMovieCollection.list_movies())
    print(myMovieCollection.get_movie("Avengers"))

main()